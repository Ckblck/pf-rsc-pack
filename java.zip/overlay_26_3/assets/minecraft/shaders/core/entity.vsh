#version 330
#extension GL_ARB_separate_shader_objects : require

// PlayFuse 26.3 (resource format 97) port of overlay_26_1 core/entity: vanilla 26.3 entity.vsh unchanged, plus three
// flat outputs at free locations 8..10 for the custom leather armor atlas (see entity.fsh). Every uniform block and
// sampler is declared under the same conditions as vanilla, because 26.3 rejects a pipeline whose shader names a
// uniform the pipeline does not bind.

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

// PlayFuse armor: the dye colour that picks an atlas column, and the shade (directional light x lightmap) the
// unlit columns use. Flat, so the whole face takes its provoking vertex, as the 26.1 shader did.
layout(location = 8) flat out vec4 armorTint;
layout(location = 9) flat out vec4 armorShadeFront;
#ifdef PER_FACE_LIGHTING
layout(location = 10) flat out vec4 armorShadeBack;
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    armorTint = Color;
#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    vec4 armorLightMap = sample_lightmap(Sampler2, UV2);
#else
    vec4 armorLightMap = vec4(1.0);
#endif
#ifdef PER_FACE_LIGHTING
    armorShadeFront = minecraft_mix_light_separate(light, vec4(1.0)) * armorLightMap;
    armorShadeBack = minecraft_mix_light_separate(-light, vec4(1.0)) * armorLightMap;
#elif defined(NO_CARDINAL_LIGHTING)
    armorShadeFront = armorLightMap;
#else
    armorShadeFront = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1.0)) * armorLightMap;
#endif
}
