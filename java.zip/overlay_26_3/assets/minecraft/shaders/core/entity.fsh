#version 330
#extension GL_ARB_separate_shader_objects : require

// PlayFuse 26.3 (resource format 97) port of overlay_26_1 core/entity. Everything that is not the custom leather
// armor atlas runs the vanilla 26.3 entity.fsh path unchanged (every #ifdef kept: per-face lighting, dissolve mask,
// glint, OIT alpha-only and accumulate passes, emissive, overlay).
//
// Custom armor: a dyed leather layer whose texture is the 11264x64 armor atlas (marker texel (0,1) is white) picks
// the atlas column whose header colour equals the dye colour, can animate (header texel 1) and can be emissive or
// tinted (header texel 2). Same rules as the 26.1 shader; only the shader syntax and the vanilla plumbing changed.

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

#define V1 32
#define V2 50

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

layout(location = 8) flat in vec4 armorTint;
layout(location = 9) flat in vec4 armorShadeFront;
#ifdef PER_FACE_LIGHTING
layout(location = 10) flat in vec4 armorShadeBack;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

// Vanilla calculateFinalColor after the overlay and lightmap steps: glint, OIT accumulation, fog.
vec4 finishColor(vec4 color) {
    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    return finishColor(color);
}

// The 26.1 custom armor branch. Returns false when this fragment is not custom armor (vanilla path runs instead).
bool customArmorColor(vec4 faceVertexColor, vec4 armorShade, out vec4 color) {
    color = vec4(0.0);
    // Most likely not a dyed armor
    if (armorTint == vec4(0.0)) {
        return false;
    }
    ivec2 atlasSize = textureSize(Sampler0, 0);
    // Check if the size of the texture matches the armor atlas texture (hacky)
    if (atlasSize != ivec2(11264, 64) || texelFetch(Sampler0, ivec2(0, 1), 0) != vec4(1.0)) {
        return false;
    }

    float armorAmount = atlasSize.x / (V1 * 4.0);
    float maxFrames = atlasSize.y / (V1 * 2.0);
    vec2 coords = texCoord0;
    coords.x /= armorAmount;
    coords.y /= maxFrames;
    vec4 textureProperties = vec4(0.0);
    vec4 customColor = vec4(0.0);
    float h_offset = 1.0 / armorAmount;
    vec2 nextFrame = vec2(0.0);
    float interpolClock = 0.0;
    vec4 vtc = faceVertexColor;
    for (int i = 1; i < (armorAmount + 1); i++) {
        customColor = texelFetch(Sampler0, ivec2(V1 * 4 * i + 0.5, 0), 0);
        if (armorTint == customColor) {
            coords.x += (h_offset * i);
            vec4 animInfo = texelFetch(Sampler0, ivec2(V1 * 4 * i + 1.5, 0), 0);
            animInfo.rgb *= animInfo.a * 255;
            textureProperties = texelFetch(Sampler0, ivec2(V1 * 4 * i + 2.5, 0), 0);
            textureProperties.rgb *= textureProperties.a * 255;
            if (animInfo != vec4(0.0)) {
                float timer = floor(mod(GameTime * V2 * animInfo.g, animInfo.r));
                if (animInfo.b > 0) interpolClock = fract(GameTime * V2 * animInfo.g);
                float v_offset = (V1 * 2.0) / atlasSize.y * timer;
                nextFrame = coords;
                coords.y += v_offset;
                nextFrame.y += (V1 * 2.0) / atlasSize.y * mod(timer + 1, animInfo.r);
            }
            break;
        }
    }
    if (textureProperties.g == 1) {
        if (textureProperties.r > 1) {
            vtc = armorTint;
        } else if (textureProperties.r == 1) {
            if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0) {
                vtc = armorTint * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
            }
        }
    } else if (textureProperties.g == 0) {
        if (textureProperties.r > 1) {
            vtc = vec4(1.0);
        } else if (textureProperties.r == 1) {
            if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0) {
                vtc = vec4(1.0) * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
            } else {
                vtc = armorShade;
            }
        } else {
            vtc = armorShade;
        }
    } else {
        vtc = armorShade;
    }
    vec4 armor = mix(texture(Sampler0, coords), texture(Sampler0, nextFrame), interpolClock);
    if (coords.x < (1 / armorAmount)) {
        color = armor * faceVertexColor * ColorModulator;
    } else {
        color = armor * vtc * ColorModulator;
    }
    return true;
}

void main() {
    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    vec4 armorShade = gl_FrontFacing ? armorShadeFront : armorShadeBack;
    #else
    vec4 faceVertexColor = vertexColor;
    vec4 armorShade = armorShadeFront;
    #endif

    #ifdef DISSOLVE
    // The dissolve effect entirely replaces translucency
    vec4 armorVertexColor = vec4(faceVertexColor.rgb, 1.0);
    #else
    vec4 armorVertexColor = faceVertexColor;
    #endif

    vec4 armorColor;
    if (customArmorColor(armorVertexColor, armorShade, armorColor)) {
        #ifdef OIT_ADDITIVE
        armorColor.a = min(0.99, armorColor.a);
        #endif
        #ifdef DISSOLVE
        // Same dissolve test as the vanilla path below: the vertex alpha is the dissolve progress, not translucency.
        if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
            discard;
        }
        #endif
        if (armorColor.a < 0.1) {
            discard;
        }
        #ifdef DISSOLVE
        armorColor.a = 1.0;
        #endif
        #ifdef GLINT
        armorColor.a = max(armorColor.a, GlintAlpha);
        #endif
        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, armorColor.a);
        #else
        // The custom columns carry their own light (armorShade or full bright), so no overlay or lightmap step.
        fragColor = finishColor(armorColor);
        #endif
        return;
    }

    vec4 color = texture(Sampler0, texCoord0);

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
